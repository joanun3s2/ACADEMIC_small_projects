public class Questao06 {
	
	public static void main(String [] args) {
		
		System.out.println("Questao 06 - Modifcacao do metodo toString \n");
		
		Tree tree = new Tree();
		
		System.out.print(tree);
	
	}

}