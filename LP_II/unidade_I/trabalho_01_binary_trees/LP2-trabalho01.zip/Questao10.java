public class Questao10 {
	
	public static void main(String[] args){
		
		Tree tree = new Tree(); 
		
		tree.levelOrderStack(); 
	}
}



